
from pathlib import Path
from typing import Optional
import os

STATE_DIR = Path(os.environ.get("STATE_DIR", "./state")).resolve()
STATE_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_POLL_INTERVAL_SEC = float(os.environ.get("POLL_INTERVAL_SEC", "0.02"))  # 20ms
DEFAULT_LOG_EVERY_N = int(os.environ.get("LOG_EVERY_N", "100"))

# Mediapipe
MP_STATIC_IMAGE_MODE = False
MP_MAX_NUM_FACES = 1
MP_MIN_DET_CONF = 0.5
MP_MIN_TRACK_CONF = 0.5
